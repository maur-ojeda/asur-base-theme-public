<?php
// Consulta el CPT 'category-showcase'. Si tienes solo uno, puedes consultarlo por su slug o ID.
$args = [
    'post_type'      => 'category-showcase',
    'posts_per_page' => 1,
    'post_status'    => 'publish',
];
$cs_query = new WP_Query($args);

if ($cs_query->have_posts()) :
    while ($cs_query->have_posts()) : $cs_query->the_post();
        // Obtiene los datos del campo complejo
        $destacados = carbon_get_the_post_meta('crb_destacados_agrupados');
        
        if (!empty($destacados)) :
            // Ordena el array por el campo 'orden_bloque'
            usort($destacados, function($a, $b) {
                return $a['orden_bloque'] <=> $b['orden_bloque'];
            });
?>
<section class="category-showcase">
    <div class="container-fluid">
        <div class="row">
            <?php foreach ($destacados as $bloque) :
                $term_data = $bloque['taxonomia_destacada'];
                
                if (empty($term_data)) {
                    continue; // Saltar si no se seleccionó una taxonomía
                }
                
                // Obtener el objeto de la taxonomía seleccionada
                $term = get_term($term_data[0]['id']);
                
                if (is_wp_error($term)) {
                    continue; // Saltar si hay un error con la taxonomía
                }

                $image_id = $bloque['image'];
                $image_url = wp_get_attachment_image_url($image_id, 'large');
                
                // Asignar los valores del objeto de la taxonomía
                $title = $term->name;
                $btn_txt = 'Ver más';
                $btn_url = get_term_link($term);
            ?>
                <div class="category-showcase-item" style="background-image: url('<?php echo esc_url(ensure_https($image_url)); ?>')">
                    <div>    
                        <h3 class="category-showcase-title text-white" data-aos="fade" data-aos-delay="200"><?= esc_html($title); ?></h3>
                        <a class="btn-krom" href="<?= esc_url($btn_url); ?>"><?= esc_html($btn_txt); ?><i data-lucide="arrow-right"></i></a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php
        endif;
    endwhile;
    wp_reset_postdata();
endif;
?>
 <div class="container my-5">
  <div class="text-start mb-4">
    <p class="text-uppercase fw-bold text-danger">EXPERTOS</p>
    <h1 class="display-4 fw-bold">NUESTRO EQUIPO</h1>
  </div>
  <div class="position-relative">
    <img src="https://picsum.photos/1200/600" class="img-fluid w-100" alt="Nuestro Equipo">
    <div class="position-absolute bottom-0 w-100" style="height: 100px; background-color: #f7a38f;">
      </div>
  </div>
</div>


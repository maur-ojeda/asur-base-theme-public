<?php get_header(); ?>

<main class="container py-5">
  <h1><?php bloginfo('name'); ?></h1>
  <p><?php bloginfo('description'); ?></p>
</main>

<?php get_footer(); ?>

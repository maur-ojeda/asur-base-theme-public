<?php
use Carbon_Fields\Container;
use Carbon_Fields\Field;


    Container::make('post_meta', 'Campos de Clientes')
        ->where('post_type', '=', 'client')
        ->add_fields([     

           Field::make('checkbox', 'is_visible', 'Mostrar esta sección')
            ->set_option_value('yes')
            ->set_width(50)
            ->set_help_text('Marca esta casilla para que la sección sea visible en la página.'),

            Field::make('complex', 'clients', 'Lista de Clientes')
                ->set_layout('tabbed-horizontal')
                ->set_duplicate_groups_allowed(true)
                ->add_fields([
                    Field::make('text', 'client_name', 'Nombre del Cliente'),                                            
                    Field::make('text', 'client_text', 'Texto descriptivo'),                        
                    Field::make('image', 'client_logo', 'Logo del Cliente')                        
                        ->set_value_type('url'),
                ]),
        ]);


<?php
/* Template Name: Front Page OnePage */
get_header();

$default_image = 'https://placehold.co/600x400@2x.png';
$default_image_features = 'https://placehold.co/350x400.png';


$info_blocks_query = new WP_Query([
    'post_type' => 'info-block',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'orderby' => 'menu_order',
    'order' => 'ASC',
]);
$info_blocks = [];

if ($info_blocks_query->have_posts()) {
    while ($info_blocks_query->have_posts()) {
        $info_blocks_query->the_post();
        $info_blocks[] = get_post(); 
        $order = carbon_get_the_post_meta('ib_order');
        if ($order) {
            $ordered_blocks[$order] = get_post();
        }
    }
    wp_reset_postdata();
}

// Obtener los posts de destacados ordenados por su campo 'orden_bloque'
$showcase_query = new WP_Query([
    'post_type' => 'category-showcase',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'meta_key' => 'orden_bloque',
    'orderby' => 'meta_value_num',
    'order' => 'ASC',
]);

$ordered_showcase_blocks = [];
if ($showcase_query->have_posts()) {
    while ($showcase_query->have_posts()) {
        $showcase_query->the_post();
        $ordered_showcase_blocks[] = get_post(); 
        $order = carbon_get_the_post_meta('orden_bloque');
        if ($order) {
            $ordered_showcase_blocks[$order] = get_post();
        }
    }
    wp_reset_postdata();
}

?>




<main id="main-content">
    <?php get_template_part('template-parts/section', 'hero'); ?>

    <?php if (isset($ordered_blocks[1])) {
        set_query_var('info_block_data', $ordered_blocks[1]);
        get_template_part('template-parts/section', 'info-block');
    } ?>

    <?php if (isset($ordered_blocks[2])) {
        set_query_var('info_block_data', $ordered_blocks[2]);
        get_template_part('template-parts/section', 'info-block');
    } ?>

    <?php if (isset($ordered_blocks[3])) {
        set_query_var('info_block_data', $ordered_blocks[3]);
        get_template_part('template-parts/section', 'info-block');
    } ?>

    <?= var_dump($ordered_showcase_blocks)?>
    
    <?php if (isset($ordered_showcase_blocks[1])) {
        set_query_var('showcase_data', $ordered_showcase_blocks[1]);
        get_template_part('template-parts/section', 'category-showcase');
    } ?>

    <?php get_template_part('template-parts/section', 'call-to-action'); ?>

    <?php if (isset($ordered_showcase_blocks[2])) {
        set_query_var('showcase_data', $ordered_showcase_blocks[2]);
        get_template_part('template-parts/section', 'category-showcase');
    } ?>
    
    <?php get_template_part('template-parts/section', 'investors'); ?>
    <?php get_template_part('template-parts/section', 'featured-project'); ?>
    <?php get_template_part('template-parts/section', 'projects'); ?>
    <?php get_template_part('template-parts/section', 'contact'); ?>
</main>

<?php get_footer(); ?>